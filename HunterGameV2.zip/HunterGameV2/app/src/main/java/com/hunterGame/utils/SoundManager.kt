package com.hunterGame.utils

import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import kotlin.math.PI
import kotlin.math.sin
import kotlin.concurrent.thread

object SoundManager {

    private val sampleRate = 44100

    fun playShot() = playTone(800.0, 0.08, 0.6)
    fun playHit()  = playTone(400.0, 0.06, 0.4)
    fun playKill() = playTone(600.0, 0.15, 0.8, true)
    fun playClick()= playTone(1200.0, 0.05, 0.3)
    fun playWin()  = playMelody(listOf(523, 659, 784, 1047), 0.15)
    fun playLose() = playMelody(listOf(400, 350, 300, 250), 0.2)
    fun playHorse()= playTone(200.0, 0.1, 0.3)

    private fun playTone(freq: Double, duration: Double, volume: Float, sweep: Boolean = false) {
        thread {
            try {
                val numSamples = (sampleRate * duration).toInt()
                val buffer = ShortArray(numSamples)
                for (i in 0 until numSamples) {
                    val f = if (sweep) freq * (1.0 + i.toDouble() / numSamples) else freq
                    val envelope = when {
                        i < numSamples * 0.1 -> i / (numSamples * 0.1)
                        i > numSamples * 0.7 -> (numSamples - i) / (numSamples * 0.3)
                        else -> 1.0
                    }
                    buffer[i] = (sin(2 * PI * f * i / sampleRate) * Short.MAX_VALUE * volume * envelope).toInt().toShort()
                }
                val track = AudioTrack(
                    AudioManager.STREAM_MUSIC, sampleRate,
                    AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT,
                    buffer.size * 2, AudioTrack.MODE_STATIC
                )
                track.write(buffer, 0, buffer.size)
                track.play()
                Thread.sleep((duration * 1000).toLong() + 100)
                track.release()
            } catch (_: Exception) {}
        }
    }

    private fun playMelody(freqs: List<Int>, noteDuration: Double) {
        thread {
            freqs.forEach { freq ->
                playTone(freq.toDouble(), noteDuration, 0.6f)
                Thread.sleep((noteDuration * 1000).toLong())
            }
        }
    }
}
