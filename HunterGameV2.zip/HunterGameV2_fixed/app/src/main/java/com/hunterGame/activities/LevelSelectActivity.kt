package com.hunterGame.activities

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.hunterGame.R
import com.hunterGame.models.AnimalCatalog
import com.hunterGame.utils.GamePreferences
import com.hunterGame.utils.SoundManager

class LevelSelectActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_level_select)

        val p = GamePreferences.loadPlayer(this)
        val grid = findViewById<GridLayout>(R.id.gridLevels)

        for (i in 1..9) {
            val animals = AnimalCatalog.getAnimalsForLevel(i).joinToString(" ") { it.emoji }
            val boss = AnimalCatalog.getBossForLevel(i).emoji
            val btn = Button(this).apply {
                text = if (i <= p.highestLevel) "Lv.$i\n$animals\n👑$boss" else "🔒\nLv.$i"
                isEnabled = i <= p.highestLevel
                textSize = 12f
                setPadding(4,4,4,4)
                setOnClickListener {
                    SoundManager.playClick()
                    // Show puzzle every 3 levels
                    if (i % 3 == 0 && i > 1) {
                        val pi = Intent(this@LevelSelectActivity, PuzzleActivity::class.java)
                        startActivity(pi)
                    }
                    val intent = Intent(this@LevelSelectActivity, GameActivity::class.java)
                    intent.putExtra("level", i)
                    startActivity(intent)
                }
            }
            val params = GridLayout.LayoutParams().apply {
                width = 0; height = GridLayout.LayoutParams.WRAP_CONTENT
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                setMargins(6,6,6,6)
            }
            btn.layoutParams = params
            grid.addView(btn)
        }
    }
}
