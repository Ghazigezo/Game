package com.hunterGame.activities

import android.graphics.Color
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.hunterGame.R
import com.hunterGame.models.TraderCatalog
import com.hunterGame.models.TraderItemType
import com.hunterGame.models.MissionCatalog
import com.hunterGame.models.MissionType
import com.hunterGame.utils.GamePreferences
import com.hunterGame.utils.SoundManager
import kotlin.random.Random

class TraderActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_trader)

        // Mark trader visited for missions
        val p = GamePreferences.loadPlayer(this)
        MissionCatalog.missions.filter { it.type == MissionType.VISIT_TRADER }.forEach { m ->
            if (!p.completedMissions.contains(m.id)) {
                p.completedMissions.add(m.id); p.coins += m.rewardCoins
                Toast.makeText(this, "🏅 مهمة مكتملة: ${m.titleAr}! +${m.rewardCoins}💰", Toast.LENGTH_LONG).show()
            }
        }
        GamePreferences.savePlayer(this, p)
        render()
    }

    private fun render() {
        val p = GamePreferences.loadPlayer(this)
        val discount = if (p.traderReputation > 5) 0.9f else 1.0f

        findViewById<TextView>(R.id.tvTraderCoins).text = "💰 ${p.coins}"
        val container = findViewById<LinearLayout>(R.id.traderContainer)
        container.removeAllViews()

        TraderCatalog.items.forEach { item ->
            val finalPrice = (item.price * discount).toInt()
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; setPadding(20,20,20,20)
                setBackgroundColor(Color.parseColor("#1A0A2E"))
                layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT).apply { setMargins(0,0,0,14) }
            }
            val info = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            info.addView(TextView(this).apply { text="${item.emoji} ${item.nameAr}"; textSize=20f; setTextColor(Color.parseColor("#DDA0DD")) })
            info.addView(TextView(this).apply { text=item.descAr; textSize=14f; setTextColor(Color.LTGRAY) })

            val btn = Button(this).apply {
                text = "💰$finalPrice"
                setBackgroundColor(Color.parseColor("#6A0DAD"))
                setTextColor(Color.WHITE)
                setOnClickListener {
                    SoundManager.playClick()
                    if (p.coins >= finalPrice) {
                        p.coins -= finalPrice
                        p.traderReputation++
                        applyItem(p, item.type, item.value)
                        GamePreferences.savePlayer(this@TraderActivity, p)
                        Toast.makeText(this@TraderActivity, "تم الشراء! ${item.emoji}", Toast.LENGTH_SHORT).show()
                        render()
                    } else {
                        Toast.makeText(this@TraderActivity, "عملاتك غير كافية 😔", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            card.addView(info); card.addView(btn); container.addView(card)
        }
    }

    private fun applyItem(p: com.hunterGame.models.PlayerState, type: TraderItemType, value: Int) {
        when (type) {
            TraderItemType.EXTRA_LIFE   -> p.lives = minOf(p.lives + value, p.maxLives + 1).also { p.maxLives = maxOf(p.maxLives, it) }
            TraderItemType.DOUBLE_COINS -> Toast.makeText(this, "💰x2 في الجولة القادمة!", Toast.LENGTH_SHORT).show()
            TraderItemType.SHIELD       -> Toast.makeText(this, "🛡️ الدرع جاهز!", Toast.LENGTH_SHORT).show()
            TraderItemType.MYSTERY_BOX  -> {
                val reward = Random.nextInt(50, 500)
                p.coins += reward
                Toast.makeText(this, "📦 الصندوق يحتوي على $reward عملة!", Toast.LENGTH_LONG).show()
            }
            TraderItemType.SPEED_BOOST  -> Toast.makeText(this, "⚡ الخيل أسرع في الجولة القادمة!", Toast.LENGTH_SHORT).show()
        }
    }
}
