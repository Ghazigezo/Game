package com.hunterGame.game

import android.content.Context
import android.graphics.Canvas
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import com.hunterGame.models.Animal
import com.hunterGame.models.AnimalCatalog
import com.hunterGame.models.GunCatalog
import com.hunterGame.models.HorseCatalog

class GameView @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null)
    : SurfaceView(context, attrs), SurfaceHolder.Callback {

    private var gameThread: GameThread? = null
    var engine: GameEngine? = null

    var level: Int = 1
    var equippedGunId: Int = 1
    var equippedHorseId: Int = 1
    var doubleCoins: Boolean = false
    var hasShield: Boolean = false
    var onAnimalKilled: ((Animal, Int, Int) -> Unit)? = null
    var onLifeLost: (() -> Unit)? = null
    var onGameOver: ((Int, Int, Boolean) -> Unit)? = null

    init { holder.addCallback(this); isFocusable = true }

    override fun surfaceCreated(holder: SurfaceHolder) {
        val gun   = GunCatalog.guns.find { it.id == equippedGunId } ?: GunCatalog.guns.first()
        val horse = HorseCatalog.horses.find { it.id == equippedHorseId } ?: HorseCatalog.horses.first()
        val animals = AnimalCatalog.getAnimalsForLevel(level)

        engine = GameEngine(
            screenWidth = width.toFloat(), screenHeight = height.toFloat(),
            level = level, gun = gun, horse = horse, animalPool = animals,
            doubleCoins = doubleCoins, hasShield = hasShield,
            onAnimalKilled = { a, s, c -> onAnimalKilled?.invoke(a, s, c) },
            onLifeLost = { onLifeLost?.invoke() },
            onGameOver = { s, c, w -> onGameOver?.invoke(s, c, w) }
        )
        gameThread = GameThread(holder, engine!!).also { it.isRunning = true; it.start() }
    }

    override fun surfaceChanged(h: SurfaceHolder, f: Int, w: Int, ht: Int) {}
    override fun surfaceDestroyed(h: SurfaceHolder) { gameThread?.isRunning = false; gameThread?.join(); gameThread = null }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.action == MotionEvent.ACTION_DOWN) engine?.shoot(e.x, e.y)
        return true
    }
}

class GameThread(private val holder: SurfaceHolder, private val engine: GameEngine) : Thread() {
    var isRunning = false
    private var lastTime = System.nanoTime()

    override fun run() {
        while (isRunning && engine.isRunning) {
            val now = System.nanoTime()
            val dt = ((now - lastTime) / 1_000_000_000f).coerceIn(0f, 0.05f)
            lastTime = now
            engine.update(dt)
            val canvas: Canvas? = holder.lockCanvas()
            if (canvas != null) try { engine.draw(canvas) } finally { holder.unlockCanvasAndPost(canvas) }
            val sleep = 16 - (System.nanoTime() - now) / 1_000_000
            if (sleep > 0) sleep(sleep)
        }
    }
}
