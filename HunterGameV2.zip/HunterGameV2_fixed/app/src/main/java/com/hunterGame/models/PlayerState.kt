package com.hunterGame.models

data class PlayerState(
    var coins: Int = 200,
    var highestLevel: Int = 1,
    var totalScore: Int = 0,
    var lives: Int = 3,
    var maxLives: Int = 3,
    var equippedGunId: Int = 1,
    var ownedGunIds: MutableList<Int> = mutableListOf(1),
    var equippedHorseId: Int = 1,
    var ownedHorseIds: MutableList<Int> = mutableListOf(1),
    var houseLevel: Int = 0,         // 0=tent, 1=hut, 2=house, 3=mansion
    var completedMissions: MutableList<Int> = mutableListOf(),
    var traderReputation: Int = 0,   // affects trader prices
    var totalAnimalsKilled: Int = 0,
    var totalPlayTime: Int = 0
)

data class Mission(
    val id: Int,
    val titleAr: String,
    val descAr: String,
    val rewardCoins: Int,
    val rewardLives: Int = 0,
    val targetCount: Int,
    val type: MissionType,
    val emoji: String
)

enum class MissionType {
    KILL_ANIMALS, REACH_LEVEL, EARN_COINS, VISIT_TRADER, BUY_HOUSE
}

object MissionCatalog {
    val missions = listOf(
        Mission(1, "الصيد الأول", "اصطد 10 حيوانات", 100, 1, 10, MissionType.KILL_ANIMALS, "🎯"),
        Mission(2, "صياد محترف", "اصطد 50 حيواناً", 300, 1, 50, MissionType.KILL_ANIMALS, "🏹"),
        Mission(3, "الفارس الأول", "تقدم للمستوى 3", 150, 0, 3, MissionType.REACH_LEVEL, "⚔️"),
        Mission(4, "التاجر الغامض", "زر التاجر مرة واحدة", 200, 1, 1, MissionType.VISIT_TRADER, "🧙"),
        Mission(5, "بيت الصياد", "اشتر خيمتك الأولى", 250, 0, 1, MissionType.BUY_HOUSE, "🏕️"),
        Mission(6, "الثري الصغير", "اجمع 1000 عملة", 400, 1, 1000, MissionType.EARN_COINS, "💰"),
        Mission(7, "صياد الوحوش", "اصطد 200 حيوان", 800, 2, 200, MissionType.KILL_ANIMALS, "🦁"),
        Mission(8, "البطل الأسطوري", "تقدم للمستوى 7", 600, 1, 7, MissionType.REACH_LEVEL, "👑")
    )
}
