package com.hunterGame.models

data class Animal(
    val id: Int,
    val nameAr: String,
    val health: Int,
    val speed: Float,
    val scoreValue: Int,
    val coinsValue: Int,
    val emoji: String,
    val size: Float = 1.0f,
    val isBoss: Boolean = false
)

object AnimalCatalog {
    fun getAnimalsForLevel(level: Int): List<Animal> = when (level) {
        1 -> listOf(rabbit)
        2 -> listOf(rabbit, fox)
        3 -> listOf(rabbit, fox, deer)
        4 -> listOf(fox, deer, wolf)
        5 -> listOf(deer, wolf, boar)
        6 -> listOf(wolf, boar, bear)
        7 -> listOf(boar, bear, lion)
        8 -> listOf(bear, lion, elephant)
        else -> listOf(lion, elephant, crocodile)
    }

    fun getBossForLevel(level: Int): Animal = when {
        level <= 2 -> foxBoss
        level <= 4 -> wolfBoss
        level <= 6 -> bearBoss
        else -> lionBoss
    }

    val rabbit    = Animal(1, "أرنب",      30,  200f, 10,  5,   "🐰")
    val fox       = Animal(2, "ثعلب",      60,  260f, 25,  15,  "🦊")
    val deer      = Animal(3, "غزال",      80,  320f, 40,  25,  "🦌")
    val wolf      = Animal(4, "ذئب",       120, 350f, 70,  40,  "🐺")
    val boar      = Animal(5, "خنزير بري", 150, 280f, 90,  55,  "🐗", 1.2f)
    val bear      = Animal(6, "دب",        220, 240f, 130, 80,  "🐻", 1.4f)
    val lion      = Animal(7, "أسد",       300, 370f, 200, 120, "🦁", 1.5f)
    val elephant  = Animal(8, "فيل",       500, 200f, 350, 200, "🐘", 2.0f)
    val crocodile = Animal(9, "تمساح",     400, 300f, 280, 160, "🐊", 1.8f)

    // Bosses
    val foxBoss  = Animal(10, "ثعلب الجهنم", 300,  300f, 150, 100, "🦊💀", 1.8f, true)
    val wolfBoss = Animal(11, "ذئب الظلام",  600,  380f, 300, 200, "🐺💀", 2.0f, true)
    val bearBoss = Animal(12, "دب الجبال",   1000, 260f, 500, 350, "🐻💀", 2.5f, true)
    val lionBoss = Animal(13, "أسد الأساطير",1500, 400f, 800, 500, "🦁👑", 3.0f, true)
}
