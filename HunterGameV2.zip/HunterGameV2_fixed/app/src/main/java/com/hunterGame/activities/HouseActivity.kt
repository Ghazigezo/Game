package com.hunterGame.activities

import android.graphics.Color
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.hunterGame.R
import com.hunterGame.models.MissionCatalog
import com.hunterGame.models.MissionType
import com.hunterGame.utils.GamePreferences
import com.hunterGame.utils.SoundManager

class HouseActivity : AppCompatActivity() {

    data class HouseTier(val nameAr: String, val emoji: String, val price: Int, val desc: String, val bonus: String)

    private val tiers = listOf(
        HouseTier("الخيمة",  "🏕️", 0,    "مسكنك الأول في البرية", "بداية جديدة"),
        HouseTier("الكوخ",   "🏚️", 500,  "كوخ دافئ بعد الصيد",   "+1 حياة مجاناً"),
        HouseTier("البيت",   "🏠", 1500, "بيت الصياد المحترف",    "+50% عملات"),
        HouseTier("القصر",   "🏰", 5000, "قصر الصياد الأسطوري",   "x2 نقاط دائماً")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_house)
        render()
    }

    private fun render() {
        val p = GamePreferences.loadPlayer(this)
        val container = findViewById<LinearLayout>(R.id.houseContainer)
        val tvCoins   = findViewById<TextView>(R.id.tvHouseCoins)
        tvCoins.text  = "💰 ${p.coins}"
        container.removeAllViews()

        // Current house display
        val current = tiers[p.houseLevel]
        container.addView(TextView(this).apply {
            text = "${current.emoji}\nبيتك الحالي: ${current.nameAr}"; textSize=28f
            setTextColor(Color.parseColor("#FFD700")); gravity=android.view.Gravity.CENTER
            setPadding(0,0,0,24)
        })

        tiers.forEachIndexed { i, tier ->
            val owned    = i <= p.houseLevel
            val isNext   = i == p.houseLevel + 1
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; setPadding(20,20,20,20)
                setBackgroundColor(if (owned) Color.parseColor("#1B5E20") else Color.parseColor("#1A1A1A"))
                layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT).apply { setMargins(0,0,0,12) }
            }
            val info = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            info.addView(TextView(this).apply { text="${tier.emoji} ${tier.nameAr}"; textSize=20f; setTextColor(Color.WHITE) })
            info.addView(TextView(this).apply { text=tier.desc; textSize=13f; setTextColor(Color.LTGRAY) })
            info.addView(TextView(this).apply { text="✨ ${tier.bonus}"; textSize=13f; setTextColor(Color.parseColor("#FFD700")) })

            val btn = Button(this).apply {
                text = when { owned -> "✅ مملوك"; isNext -> "💰${tier.price}"; else -> "🔒" }
                isEnabled = isNext
                setOnClickListener {
                    SoundManager.playWin()
                    if (p.coins >= tier.price) {
                        p.coins -= tier.price; p.houseLevel = i
                        // Mission
                        MissionCatalog.missions.filter { it.type == MissionType.BUY_HOUSE }.forEach { m ->
                            if (!p.completedMissions.contains(m.id)) {
                                p.completedMissions.add(m.id); p.coins += m.rewardCoins
                                Toast.makeText(this@HouseActivity, "🏅 ${m.titleAr}! +${m.rewardCoins}💰", Toast.LENGTH_LONG).show()
                            }
                        }
                        GamePreferences.savePlayer(this@HouseActivity, p)
                        Toast.makeText(this@HouseActivity, "تهانينا! اشتريت ${tier.emoji} ${tier.nameAr}!", Toast.LENGTH_LONG).show()
                        render()
                    } else Toast.makeText(this@HouseActivity, "عملاتك غير كافية 😔", Toast.LENGTH_SHORT).show()
                }
            }
            card.addView(info); card.addView(btn); container.addView(card)
        }
    }
}
