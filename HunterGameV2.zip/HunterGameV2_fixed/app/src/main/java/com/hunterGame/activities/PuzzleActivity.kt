package com.hunterGame.activities

import android.graphics.Color
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.hunterGame.R
import com.hunterGame.utils.GamePreferences
import com.hunterGame.utils.SoundManager
import kotlin.random.Random

class PuzzleActivity : AppCompatActivity() {

    data class Puzzle(val question: String, val options: List<String>, val correct: Int, val reward: Int)

    private val puzzles = listOf(
        Puzzle("🐰 أسرع حيوان في اللعبة؟", listOf("الأرنب","الأسد","الغزال","الذئب"), 2, 100),
        Puzzle("🔫 كم رصاصة في الثانية لمدفع الرعد؟", listOf("1","2","3","4"), 2, 150),
        Puzzle("🏠 كم مستوى للبيت؟", listOf("2","3","4","5"), 2, 100),
        Puzzle("🐘 كم نقطة قيمة الفيل؟", listOf("200","280","350","500"), 2, 200),
        Puzzle("🧙 من هو التاجر الغامض؟", listOf("صديق","عدو","لغز","إنسان"), 2, 120),
        Puzzle("⭐ كم مستوى في اللعبة؟", listOf("5","7","9","12"), 2, 100),
        Puzzle("🐴 أسرع خيل في المتجر؟", listOf("الحمار","الفرس الرشيق","جواد الصحراء","الفارس الأسطوري"), 3, 200),
        Puzzle("💰 ما مكافأة صيد الأسد؟", listOf("80","120","200","350"), 2, 150)
    )

    private val puzzle = puzzles[Random.nextInt(puzzles.size)]
    private var answered = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_puzzle)

        val reward = intent.getIntExtra("reward", puzzle.reward)
        findViewById<TextView>(R.id.tvPuzzleQ).text = puzzle.question
        findViewById<TextView>(R.id.tvPuzzleReward).text = "🏆 الجائزة: 💰${puzzle.reward} عملة"

        val buttons = listOf(
            findViewById<Button>(R.id.btnOpt0),
            findViewById<Button>(R.id.btnOpt1),
            findViewById<Button>(R.id.btnOpt2),
            findViewById<Button>(R.id.btnOpt3)
        )

        puzzle.options.forEachIndexed { i, opt ->
            buttons[i].text = opt
            buttons[i].setOnClickListener {
                if (answered) return@setOnClickListener
                answered = true
                if (i == puzzle.correct) {
                    SoundManager.playWin()
                    buttons[i].setBackgroundColor(Color.parseColor("#2E7D32"))
                    val p = GamePreferences.loadPlayer(this)
                    p.coins += puzzle.reward
                    GamePreferences.savePlayer(this, p)
                    findViewById<TextView>(R.id.tvPuzzleResult).text = "✅ صحيح! +${puzzle.reward}💰"
                } else {
                    SoundManager.playLose()
                    buttons[i].setBackgroundColor(Color.RED)
                    buttons[puzzle.correct].setBackgroundColor(Color.parseColor("#2E7D32"))
                    findViewById<TextView>(R.id.tvPuzzleResult).text = "❌ خطأ! الجواب: ${puzzle.options[puzzle.correct]}"
                }
                android.os.Handler(mainLooper).postDelayed({ finish() }, 2000)
            }
        }
    }
}
