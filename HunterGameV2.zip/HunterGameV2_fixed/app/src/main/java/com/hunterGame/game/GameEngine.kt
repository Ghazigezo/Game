package com.hunterGame.game

import android.graphics.*
import com.hunterGame.models.Animal
import com.hunterGame.models.AnimalCatalog
import com.hunterGame.models.Gun
import com.hunterGame.models.Horse
import com.hunterGame.utils.SoundManager
import kotlin.math.*
import kotlin.random.Random

data class AnimalEntity(
    val animal: Animal,
    var x: Float,
    var lane: Int,          // 0=far, 1=mid, 2=near — 3D lanes
    var currentHealth: Int,
    val id: Int = Random.nextInt()
) {
    val maxHealth get() = animal.health
    val healthRatio get() = currentHealth.toFloat() / maxHealth
    var isAlive = true
    var direction = if (Random.nextBoolean()) 1f else -1f
    var flashTimer = 0f
    var laneChangeTimer = Random.nextFloat() * 3f
    // Scale based on lane (perspective)
    val scale get() = 0.5f + lane * 0.35f
}

data class BulletEntity(var x: Float, var y: Float, val damage: Int, val targetLane: Int, val speed: Float = 1100f)

data class ParticleEntity(var x: Float, var y: Float, var vx: Float, var vy: Float, var life: Float, val emoji: String)

class GameEngine(
    private val screenWidth: Float,
    private val screenHeight: Float,
    val level: Int,
    private val gun: Gun,
    private val horse: Horse,
    private val animalPool: List<Animal>,
    private var doubleCoins: Boolean = false,
    private var hasShield: Boolean = false,
    val onAnimalKilled: (Animal, Int, Int) -> Unit,
    val onLifeLost: () -> Unit,
    val onGameOver: (Int, Int, Boolean) -> Unit   // score, coins, won
) {
    private val animals  = mutableListOf<AnimalEntity>()
    private val bullets  = mutableListOf<BulletEntity>()
    private val particles= mutableListOf<ParticleEntity>()

    var score = 0; var coinsEarned = 0
    var isRunning = true
    var isPaused = false

    private val animalsToKill = 5 + level * 3
    private val spawnInterval = max(0.6f, 2.2f - level * 0.12f)
    private val timeLimit = 70f + level * 8f

    private var animalsKilled = 0
    private var spawnTimer = 0f
    private var timeRemaining = timeLimit
    private var shotCooldown = 0f
    private val shotCooldownMax = 1f / gun.fireRate
    private var horseX = 180f
    private var horseAnim = 0f
    private var bossSpawned = false
    private var shieldActive = hasShield

    // 3D lane Y positions
    private val laneY = floatArrayOf(
        screenHeight * 0.45f,   // far (small)
        screenHeight * 0.60f,   // mid
        screenHeight * 0.72f    // near (big)
    )

    // Paints
    private val skyTop    = Paint().apply { color = Color.parseColor("#87CEEB") }
    private val skyBottom = Paint().apply { color = Color.parseColor("#C8E6F7") }
    private val groundFar = Paint().apply { color = Color.parseColor("#7CB87C") }
    private val groundMid = Paint().apply { color = Color.parseColor("#5C9A3C") }
    private val groundNear= Paint().apply { color = Color.parseColor("#4A7A2C") }
    private val mountainPaint = Paint().apply { color = Color.parseColor("#8B9A7B"); isAntiAlias=true }
    private val treePaint = Paint().apply { color = Color.parseColor("#2D5A1B"); isAntiAlias=true }
    private val pathPaint = Paint().apply { color = Color.parseColor("#C4A35A"); isAntiAlias=true }
    private val sunPaint  = Paint().apply { color = Color.parseColor("#FFD700"); isAntiAlias=true }
    private val uiPaint   = Paint().apply { color=Color.WHITE; textSize=50f; typeface=Typeface.DEFAULT_BOLD; isAntiAlias=true }
    private val smallPaint= Paint().apply { color=Color.parseColor("#FFD700"); textSize=38f; typeface=Typeface.DEFAULT_BOLD; isAntiAlias=true }
    private val hpBg      = Paint().apply { color=Color.parseColor("#AA000000"); style=Paint.Style.FILL }
    private val hpRed     = Paint().apply { color=Color.parseColor("#FF4444"); style=Paint.Style.FILL }
    private val hpGreen   = Paint().apply { color=Color.parseColor("#44FF44"); style=Paint.Style.FILL }
    private val hpBoss    = Paint().apply { color=Color.parseColor("#FF8800"); style=Paint.Style.FILL }
    private val flashPaint= Paint().apply { color=Color.parseColor("#88FF0000"); style=Paint.Style.FILL }
    private val shieldPaint=Paint().apply { color=Color.parseColor("#4400AAFF"); style=Paint.Style.FILL; isAntiAlias=true }
    private val emojiPaint= Paint().apply { textSize=90f; isAntiAlias=true }
    private val bossBg    = Paint().apply { color=Color.parseColor("#CC000000"); style=Paint.Style.FILL }

    fun update(dt: Float) {
        if (!isRunning || isPaused) return
        timeRemaining -= dt
        spawnTimer += dt
        horseAnim += dt * 8f * horse.speed
        if (shotCooldown > 0) shotCooldown -= dt

        // Spawn boss at halfway
        if (!bossSpawned && animalsKilled >= animalsToKill / 2) {
            spawnBoss(); bossSpawned = true
        }

        // Spawn normal animals
        if (spawnTimer >= spawnInterval && animals.count { it.isAlive && !it.animal.isBoss } < 6) {
            spawnAnimal(); spawnTimer = 0f
        }

        // Move animals
        animals.filter { it.isAlive }.forEach { e ->
            e.x += e.direction * e.animal.speed * horse.speed * 0.6f * dt * e.scale
            e.flashTimer = max(0f, e.flashTimer - dt)
            e.laneChangeTimer -= dt
            if (e.laneChangeTimer <= 0 && !e.animal.isBoss) {
                e.lane = Random.nextInt(3)
                e.laneChangeTimer = 2f + Random.nextFloat() * 3f
            }
            val hw = emojiSz(e) / 2f
            if (e.x - hw < 0) { e.x = hw; e.direction = 1f }
            else if (e.x + hw > screenWidth) { e.x = screenWidth - hw; e.direction = -1f }
        }

        // Move bullets
        bullets.forEach { it.x += it.speed * dt }
        bullets.removeAll { it.x > screenWidth + 100 }

        // Particles
        particles.forEach { p -> p.x+=p.vx*dt; p.y+=p.vy*dt; p.vy+=200f*dt; p.life-=dt }
        particles.removeAll { it.life <= 0 }

        // Collision
        val deadBullets = mutableListOf<BulletEntity>()
        bullets.forEach { bullet ->
            animals.filter { it.isAlive && it.lane == bullet.targetLane }.forEach { e ->
                val hw = emojiSz(e) / 2f
                if (abs(bullet.x - e.x) < hw && abs(bullet.y - laneY[e.lane]) < emojiSz(e)) {
                    e.currentHealth -= bullet.damage
                    e.flashTimer = 0.12f
                    deadBullets.add(bullet)
                    SoundManager.playHit()
                    if (e.currentHealth <= 0) {
                        e.isAlive = false
                        if (!e.animal.isBoss) animalsKilled++
                        val coins = if (doubleCoins) e.animal.coinsValue * 2 else e.animal.coinsValue
                        score += e.animal.scoreValue
                        coinsEarned += coins
                        onAnimalKilled(e.animal, e.animal.scoreValue, coins)
                        SoundManager.playKill()
                        spawnParticles(e.x, laneY[e.lane], e.animal.emoji)
                    }
                }
            }
        }
        bullets.removeAll(deadBullets)
        animals.removeAll { !it.isAlive && it.flashTimer <= 0f }

        // Win / Lose
        if (animalsKilled >= animalsToKill && animals.none { it.isAlive && it.animal.isBoss }) {
            isRunning = false; SoundManager.playWin(); onGameOver(score, coinsEarned, true)
        } else if (timeRemaining <= 0) {
            isRunning = false; SoundManager.playLose(); onGameOver(score, coinsEarned, false)
        }
    }

    fun shoot(tapX: Float, tapY: Float) {
        if (shotCooldown > 0 || !isRunning || isPaused) return
        shotCooldown = shotCooldownMax
        // Determine which lane was tapped
        val lane = when {
            tapY < laneY[0] + 40 -> 0
            tapY < laneY[1] + 40 -> 1
            else -> 2
        }
        bullets.add(BulletEntity(x = horseX + 80f, y = laneY[lane], damage = gun.damage, targetLane = lane))
        SoundManager.playShot()
    }

    fun draw(canvas: Canvas) {
        drawBackground(canvas)
        drawAnimals(canvas)
        drawBullets(canvas)
        drawParticles(canvas)
        drawPlayer(canvas)
        drawHUD(canvas)
        if (shieldActive) drawShield(canvas)
        drawBossBar(canvas)
    }

    // ── Drawing ──────────────────────────────────────────────────────────────

    private fun drawBackground(canvas: Canvas) {
        // Sky gradient simulation
        canvas.drawRect(0f, 0f, screenWidth, screenHeight * 0.38f, skyTop)
        canvas.drawRect(0f, screenHeight * 0.38f, screenWidth, screenHeight * 0.42f, skyBottom)

        // Sun
        canvas.drawCircle(screenWidth * 0.85f, screenHeight * 0.12f, 55f, sunPaint)

        // Mountains (far)
        val mPts = listOf(0f to 0.38f, 0.1f to 0.26f, 0.2f to 0.32f, 0.35f to 0.22f,
            0.5f to 0.30f, 0.65f to 0.25f, 0.8f to 0.32f, 1.0f to 0.28f, 1.0f to 0.42f, 0f to 0.42f)
        val mPath = Path()
        mPts.forEachIndexed { i, (x, y) ->
            if (i == 0) mPath.moveTo(x * screenWidth, y * screenHeight)
            else mPath.lineTo(x * screenWidth, y * screenHeight)
        }
        mPath.close(); canvas.drawPath(mPath, mountainPaint)

        // Ground layers (3D perspective strips)
        canvas.drawRect(0f, screenHeight*0.42f, screenWidth, screenHeight*0.52f, groundFar)
        canvas.drawRect(0f, screenHeight*0.52f, screenWidth, screenHeight*0.64f, groundMid)
        canvas.drawRect(0f, screenHeight*0.64f, screenWidth, screenHeight, groundNear)

        // Path (dirt road perspective)
        val path = Path()
        path.moveTo(screenWidth*0.42f, screenHeight*0.42f)
        path.lineTo(screenWidth*0.58f, screenHeight*0.42f)
        path.lineTo(screenWidth*0.85f, screenHeight)
        path.lineTo(screenWidth*0.15f, screenHeight)
        path.close(); canvas.drawPath(path, pathPaint)

        // Trees (decorative)
        drawTree(canvas, screenWidth*0.05f, screenHeight*0.44f, 0.4f)
        drawTree(canvas, screenWidth*0.18f, screenHeight*0.46f, 0.5f)
        drawTree(canvas, screenWidth*0.88f, screenHeight*0.44f, 0.4f)
        drawTree(canvas, screenWidth*0.75f, screenHeight*0.47f, 0.5f)
    }

    private fun drawTree(canvas: Canvas, x: Float, y: Float, scale: Float) {
        emojiPaint.textSize = 80f * scale
        canvas.drawText("🌴", x, y, emojiPaint)
    }

    private fun drawAnimals(canvas: Canvas) {
        // Draw far-to-near (painter's algorithm)
        listOf(0, 1, 2).forEach { lane ->
            animals.filter { it.isAlive && it.lane == lane }.forEach { e ->
                val sz = emojiSz(e)
                val y = laneY[e.lane]
                if (e.flashTimer > 0) canvas.drawCircle(e.x, y, sz/2f, flashPaint)
                // Shadow
                val shadowPaint = Paint().apply { color=Color.parseColor("#44000000"); style=Paint.Style.FILL }
                canvas.drawOval(RectF(e.x-sz*0.4f, y+sz*0.1f, e.x+sz*0.4f, y+sz*0.2f), shadowPaint)
                // Emoji
                emojiPaint.textSize = sz
                canvas.drawText(e.animal.emoji, e.x - sz/2f, y + sz*0.35f, emojiPaint)
                // HP bar
                val bw = sz*1.2f; val bh = 12f; val bx = e.x-bw/2f; val by = y-sz*0.6f
                canvas.drawRoundRect(RectF(bx,by,bx+bw,by+bh), 5f,5f, hpBg)
                val fp = if (e.animal.isBoss) hpBoss else if (e.healthRatio>0.5f) hpGreen else hpRed
                canvas.drawRoundRect(RectF(bx,by,bx+bw*e.healthRatio,by+bh), 5f,5f, fp)
                // Boss label
                if (e.animal.isBoss) {
                    emojiPaint.textSize = 28f
                    canvas.drawText("👑 BOSS", e.x-40f, by-8f, emojiPaint)
                }
            }
        }
    }

    private fun drawBullets(canvas: Canvas) {
        val bp = Paint().apply { color=Color.YELLOW; style=Paint.Style.FILL }
        bullets.forEach { b ->
            canvas.drawCircle(b.x, b.y, 12f + b.targetLane*4f, bp)
            // Bullet trail
            val tp = Paint().apply { color=Color.parseColor("#88FFFF00"); style=Paint.Style.FILL }
            canvas.drawCircle(b.x-30f, b.y, 6f, tp)
        }
    }

    private fun drawParticles(canvas: Canvas) {
        particles.forEach { p ->
            emojiPaint.textSize = 40f * p.life
            canvas.drawText(p.emoji, p.x, p.y, emojiPaint)
        }
    }

    private fun drawPlayer(canvas: Canvas) {
        val bounce = sin(horseAnim) * 8f
        val hY = laneY[2] + bounce
        // Horse
        emojiPaint.textSize = 100f
        canvas.drawText(horse.emoji, horseX - 120f, hY + 10f, emojiPaint)
        // Arab hunter
        emojiPaint.textSize = 90f
        canvas.drawText("🧔🏽", horseX - 30f, hY - 20f, emojiPaint)
        // Gun
        emojiPaint.textSize = 60f
        canvas.drawText(gun.emoji, horseX + 50f, hY - 30f, emojiPaint)
    }

    private fun drawShield(canvas: Canvas) {
        canvas.drawCircle(horseX, laneY[2] - 40f, 90f, shieldPaint)
        emojiPaint.textSize = 40f
        canvas.drawText("🛡️", horseX - 20f, laneY[2] - 100f, emojiPaint)
    }

    private fun drawHUD(canvas: Canvas) {
        // Score / coins
        uiPaint.color = Color.WHITE
        canvas.drawText("🏆 $score", 16f, 52f, uiPaint)
        smallPaint.color = Color.parseColor("#FFD700")
        canvas.drawText("💰 $coinsEarned", 16f, 96f, smallPaint)

        // Progress
        uiPaint.color = Color.WHITE
        canvas.drawText("🎯 $animalsKilled/$animalsToKill", screenWidth/2f - 120f, 52f, uiPaint)

        // Timer
        val tc = if (timeRemaining < 15f) Color.RED else Color.WHITE
        uiPaint.color = tc
        canvas.drawText("⏱ ${timeRemaining.toInt()}s", screenWidth - 220f, 52f, uiPaint)
        uiPaint.color = Color.WHITE

        // Level + gun
        smallPaint.textSize = 34f
        canvas.drawText("Lv.$level  ${gun.emoji}", screenWidth - 200f, 92f, smallPaint)
    }

    private fun drawBossBar(canvas: Canvas) {
        val boss = animals.firstOrNull { it.isAlive && it.animal.isBoss } ?: return
        val bw = screenWidth * 0.6f; val bh = 22f
        val bx = screenWidth/2f - bw/2f; val by = screenHeight - 50f
        canvas.drawRoundRect(RectF(bx-4f, by-4f, bx+bw+4f, by+bh+4f), 10f,10f, bossBg)
        canvas.drawRoundRect(RectF(bx,by,bx+bw,by+bh), 10f,10f, hpBg)
        canvas.drawRoundRect(RectF(bx,by,bx+bw*boss.healthRatio,by+bh), 10f,10f, hpBoss)
        smallPaint.textSize = 30f; smallPaint.color = Color.WHITE
        canvas.drawText("${boss.animal.nameAr} ${boss.animal.emoji}", bx+8f, by-6f, smallPaint)
    }

    // ── Helpers ──────────────────────────────────────────────────────────────

    private fun spawnAnimal() {
        val animal = animalPool.random()
        val lane = Random.nextInt(3)
        val dir = if (Random.nextBoolean()) 1f else -1f
        val x = if (dir > 0) -100f else screenWidth + 100f
        animals.add(AnimalEntity(animal, x, lane, animal.health).apply { direction = dir })
    }

    private fun spawnBoss() {
        val boss = AnimalCatalog.getBossForLevel(level)
        animals.add(AnimalEntity(boss, screenWidth * 0.7f, 1, boss.health).apply { direction = -1f })
    }

    private fun spawnParticles(x: Float, y: Float, emoji: String) {
        repeat(5) {
            particles.add(ParticleEntity(x, y,
                Random.nextFloat()*400f-200f, Random.nextFloat()*-300f-100f,
                0.6f + Random.nextFloat()*0.4f, emoji))
        }
    }

    private fun emojiSz(e: AnimalEntity) = 90f * e.animal.size * e.scale
}
