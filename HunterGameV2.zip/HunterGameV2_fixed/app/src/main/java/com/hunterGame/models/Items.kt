package com.hunterGame.models

data class Gun(
    val id: Int,
    val nameAr: String,
    val damage: Int,
    val fireRate: Int,
    val price: Int,
    val emoji: String,
    val range: Float = 1.0f
)

data class Horse(
    val id: Int,
    val nameAr: String,
    val speed: Float,
    val price: Int,
    val emoji: String,
    val description: String
)

object GunCatalog {
    val guns = listOf(
        Gun(1, "مسدس الصحراء",  damage=20, fireRate=1, price=0,    emoji="🔫"),
        Gun(2, "بندقية الصياد", damage=45, fireRate=1, price=500,  emoji="🎯"),
        Gun(3, "قاطعة الريح",   damage=60, fireRate=2, price=1200, emoji="💨"),
        Gun(4, "مدفع الصحراء",  damage=90, fireRate=1, price=2500, emoji="💥"),
        Gun(5, "بندقية الفالكون",damage=120,fireRate=1, price=4000, emoji="🦅"),
        Gun(6, "مدفع الرعد",    damage=75, fireRate=3, price=6000, emoji="⚡")
    )
}

object HorseCatalog {
    val horses = listOf(
        Horse(1, "الحمار الوفي",   speed=1.0f, price=0,    emoji="🐴", description="بطيء لكن موثوق"),
        Horse(2, "الفرس الرشيق",   speed=1.5f, price=800,  emoji="🐎", description="سريع ورشيق"),
        Horse(3, "جواد الصحراء",   speed=2.0f, price=2000, emoji="🏇", description="ابن الصحراء الأصيل"),
        Horse(4, "الفارس الأسطوري",speed=2.8f, price=5000, emoji="⚡", description="أسرع خيل في الأرض")
    )
}

// Mysterious Trader items
data class TraderItem(
    val id: Int,
    val nameAr: String,
    val descAr: String,
    val price: Int,
    val emoji: String,
    val type: TraderItemType,
    val value: Int
)

enum class TraderItemType { EXTRA_LIFE, DOUBLE_COINS, SHIELD, MYSTERY_BOX, SPEED_BOOST }

object TraderCatalog {
    val items = listOf(
        TraderItem(1, "حياة إضافية",    "أضف حياة لرصيدك",        price=300, emoji="❤️",  type=TraderItemType.EXTRA_LIFE,    value=1),
        TraderItem(2, "مضاعف العملات", "ضاعف عملاتك للجولة القادمة",price=500, emoji="💰x2",type=TraderItemType.DOUBLE_COINS,  value=2),
        TraderItem(3, "درع الصياد",    "احمِك من الهجوم مرة",      price=400, emoji="🛡️",  type=TraderItemType.SHIELD,        value=1),
        TraderItem(4, "صندوق الغموض",  "جائزة مفاجئة!",           price=200, emoji="📦",  type=TraderItemType.MYSTERY_BOX,   value=0),
        TraderItem(5, "جرعة السرعة",   "الحصان أسرع لجولة",       price=350, emoji="⚡",  type=TraderItemType.SPEED_BOOST,   value=2)
    )
}
