package com.hunterGame.activities

import android.graphics.Color
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.hunterGame.R
import com.hunterGame.models.GunCatalog
import com.hunterGame.models.HorseCatalog
import com.hunterGame.utils.GamePreferences
import com.hunterGame.utils.SoundManager

class ShopActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_shop)
        render()
    }

    private fun render() {
        val p = GamePreferences.loadPlayer(this)
        findViewById<TextView>(R.id.tvShopCoins).text = "💰 ${p.coins}"
        val container = findViewById<LinearLayout>(R.id.shopContainer)
        container.removeAllViews()

        // Section: Guns
        addHeader(container, "🔫 الأسلحة")
        GunCatalog.guns.forEach { gun ->
            val owned    = p.ownedGunIds.contains(gun.id)
            val equipped = p.equippedGunId == gun.id
            addCard(container,
                "${gun.emoji} ${gun.nameAr}",
                "ضرر: ${gun.damage}  معدل: ${gun.fireRate}/ث",
                if (equipped) "✅ مجهز" else if (owned) "تجهيز" else "💰${gun.price}",
                !equipped,
                if (equipped) Color.parseColor("#2E7D32") else Color.parseColor("#1A1A2E")
            ) {
                SoundManager.playClick()
                if (owned) { p.equippedGunId = gun.id }
                else if (p.coins >= gun.price) { p.coins -= gun.price; p.ownedGunIds.add(gun.id); p.equippedGunId = gun.id }
                else Toast.makeText(this, "عملاتك غير كافية 😔", Toast.LENGTH_SHORT).show()
                GamePreferences.savePlayer(this, p); render()
            }
        }

        // Section: Horses
        addHeader(container, "🐴 الخيول")
        HorseCatalog.horses.forEach { horse ->
            val owned    = p.ownedHorseIds.contains(horse.id)
            val equipped = p.equippedHorseId == horse.id
            addCard(container,
                "${horse.emoji} ${horse.nameAr}",
                "سرعة: ${"⭐".repeat((horse.speed*1.5f).toInt())}  ${horse.description}",
                if (equipped) "✅ مجهز" else if (owned) "تجهيز" else "💰${horse.price}",
                !equipped,
                if (equipped) Color.parseColor("#4A1A6E") else Color.parseColor("#1A1A2E")
            ) {
                SoundManager.playHorse()
                if (owned) { p.equippedHorseId = horse.id }
                else if (p.coins >= horse.price) { p.coins -= horse.price; p.ownedHorseIds.add(horse.id); p.equippedHorseId = horse.id }
                else Toast.makeText(this, "عملاتك غير كافية 😔", Toast.LENGTH_SHORT).show()
                GamePreferences.savePlayer(this, p); render()
            }
        }
    }

    private fun addHeader(container: LinearLayout, text: String) {
        container.addView(TextView(this).apply {
            this.text = text; textSize = 22f; setTextColor(Color.parseColor("#FFD700"))
            setPadding(8, 20, 8, 8)
        })
    }

    private fun addCard(container: LinearLayout, title: String, desc: String, btnText: String,
                        btnEnabled: Boolean, bgColor: Int, onClick: () -> Unit) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; setPadding(20,20,20,20)
            setBackgroundColor(bgColor)
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT).apply { setMargins(0,0,0,12) }
        }
        val info = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        info.addView(TextView(this).apply { this.text=title; textSize=19f; setTextColor(Color.WHITE) })
        info.addView(TextView(this).apply { this.text=desc;  textSize=13f; setTextColor(Color.LTGRAY) })
        val btn = Button(this).apply { text=btnText; isEnabled=btnEnabled; setOnClickListener { onClick() } }
        card.addView(info); card.addView(btn); container.addView(card)
    }
}
