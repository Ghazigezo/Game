package com.hunterGame.activities

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.hunterGame.R
import com.hunterGame.game.GameView
import com.hunterGame.models.MissionCatalog
import com.hunterGame.models.MissionType
import com.hunterGame.utils.GamePreferences

class GameActivity : AppCompatActivity() {
    private lateinit var gameView: GameView
    private var level = 1
    private var gameOverShown = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_game)

        level = intent.getIntExtra("level", 1)
        val player = GamePreferences.loadPlayer(this)

        gameView = findViewById(R.id.gameView)
        gameView.level = level
        gameView.equippedGunId   = player.equippedGunId
        gameView.equippedHorseId = player.equippedHorseId
        gameView.doubleCoins = intent.getBooleanExtra("doubleCoins", false)
        gameView.hasShield   = intent.getBooleanExtra("shield", false)

        gameView.onAnimalKilled = { animal, score, coins ->
            runOnUiThread {
                val tv = findViewById<TextView>(R.id.tvKillFeed)
                tv.text = "${animal.emoji} +$score pts  💰+$coins"
                tv.visibility = View.VISIBLE
                Handler(Looper.getMainLooper()).postDelayed({ tv.visibility = View.GONE }, 1200)
            }
        }

        gameView.onGameOver = { score, coins, won ->
            runOnUiThread { showGameOver(score, coins, won) }
        }

        // Pause button
        findViewById<View>(R.id.btnPause).setOnClickListener {
            gameView.engine?.isPaused = !(gameView.engine?.isPaused ?: false)
            (it as TextView).text = if (gameView.engine?.isPaused == true) "▶" else "⏸"
        }
    }

    private fun showGameOver(score: Int, coins: Int, won: Boolean) {
        if (gameOverShown) return; gameOverShown = true
        val player = GamePreferences.loadPlayer(this)
        player.coins += coins
        player.totalScore += score
        player.totalAnimalsKilled += score / 10
        if (won && level >= player.highestLevel) player.highestLevel = minOf(level + 1, 9)

        // Check missions
        val newMissions = mutableListOf<String>()
        MissionCatalog.missions.forEach { m ->
            if (!player.completedMissions.contains(m.id)) {
                val done = when (m.type) {
                    MissionType.KILL_ANIMALS -> player.totalAnimalsKilled >= m.targetCount
                    MissionType.REACH_LEVEL  -> player.highestLevel >= m.targetCount
                    MissionType.EARN_COINS   -> player.totalScore >= m.targetCount
                    else -> false
                }
                if (done) {
                    player.completedMissions.add(m.id)
                    player.coins += m.rewardCoins
                    player.lives = minOf(player.lives + m.rewardLives, player.maxLives)
                    newMissions.add("${m.emoji} ${m.titleAr}: +${m.rewardCoins}💰")
                }
            }
        }
        GamePreferences.savePlayer(this, player)

        val title = if (won) "🎉 فزت يا بطل!" else "💀 انتهت الجولة"
        val missionMsg = if (newMissions.isNotEmpty()) "\n\n🏅 مهمات مكتملة:\n${newMissions.joinToString("\n")}" else ""

        AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage("النقاط: $score\nعملات: 💰$coins$missionMsg")
            .setCancelable(false)
            .setPositiveButton("🏠 الرئيسية") { _,_ -> startActivity(Intent(this, MainActivity::class.java)); finish() }
            .setNegativeButton("🔄 إعادة") { _,_ ->
                val i = Intent(this, GameActivity::class.java); i.putExtra("level", level); startActivity(i); finish()
            }
            .show()
    }
}
