package com.hunterGame.activities

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.hunterGame.R
import com.hunterGame.utils.GamePreferences
import com.hunterGame.utils.SoundManager

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    override fun onResume() {
        super.onResume()
        val p = GamePreferences.loadPlayer(this)
        findViewById<TextView>(R.id.tvCoins).text   = "💰 ${p.coins}"
        findViewById<TextView>(R.id.tvScore).text   = "🏆 ${p.totalScore}"
        findViewById<TextView>(R.id.tvLevel).text   = "⚔️ Lv.${p.highestLevel}"
        val hearts = "❤️".repeat(p.lives) + "🖤".repeat(p.maxLives - p.lives)
        findViewById<TextView>(R.id.tvLives).text   = hearts
        findViewById<TextView>(R.id.tvHouse).text   = houseEmoji(p.houseLevel)

        findViewById<Button>(R.id.btnPlay).setOnClickListener {
            SoundManager.playClick()
            startActivity(Intent(this, LevelSelectActivity::class.java))
        }
        findViewById<Button>(R.id.btnShop).setOnClickListener {
            SoundManager.playClick()
            startActivity(Intent(this, ShopActivity::class.java))
        }
        findViewById<Button>(R.id.btnTrader).setOnClickListener {
            SoundManager.playClick()
            startActivity(Intent(this, TraderActivity::class.java))
        }
        findViewById<Button>(R.id.btnHouse).setOnClickListener {
            SoundManager.playClick()
            startActivity(Intent(this, HouseActivity::class.java))
        }
        findViewById<Button>(R.id.btnMissions).setOnClickListener {
            SoundManager.playClick()
            startActivity(Intent(this, MissionsActivity::class.java))
        }
    }

    private fun houseEmoji(level: Int) = when(level) {
        0 -> "🏕️ خيمة"; 1 -> "🏚️ كوخ"; 2 -> "🏠 بيت"; 3 -> "🏰 قصر"; else -> "🏕️"
    }
}
