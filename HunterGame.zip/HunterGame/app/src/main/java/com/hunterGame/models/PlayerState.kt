package com.hunterGame.models

data class PlayerState(
    var coins: Int = 100,
    var highestLevel: Int = 1,
    var totalScore: Int = 0,
    var equippedGunId: Int = 1,
    var ownedGunIds: MutableList<Int> = mutableListOf(1)
)
