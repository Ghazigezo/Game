package com.hunterGame.models

data class Gun(
    val id: Int,
    val nameAr: String,
    val nameEn: String,
    val damage: Int,
    val fireRate: Int,        // shots per second
    val price: Int,
    val emoji: String,
    var isOwned: Boolean = false,
    var isEquipped: Boolean = false
)

object GunCatalog {
    val guns = listOf(
        Gun(1, "مسدس الصحراء", "Desert Pistol",   damage = 20, fireRate = 1, price = 0,    emoji = "🔫", isOwned = true),
        Gun(2, "بندقية الصياد", "Hunter Rifle",    damage = 45, fireRate = 1, price = 500,  emoji = "🎯"),
        Gun(3, "قاطعة الريح",   "Wind Cutter",     damage = 60, fireRate = 2, price = 1200, emoji = "💨"),
        Gun(4, "مدفع الصحراء",  "Desert Cannon",   damage = 90, fireRate = 1, price = 2500, emoji = "💥"),
        Gun(5, "بندقية الفالكون","Falcon Sniper",   damage = 120,fireRate = 1, price = 4000, emoji = "🦅"),
        Gun(6, "مدفع الرعد",    "Thunder Machine",  damage = 75, fireRate = 3, price = 6000, emoji = "⚡")
    )
}
