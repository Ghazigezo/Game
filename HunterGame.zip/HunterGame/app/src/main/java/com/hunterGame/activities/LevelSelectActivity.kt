package com.hunterGame.activities

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.GridLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.hunterGame.R
import com.hunterGame.models.AnimalCatalog
import com.hunterGame.utils.GamePreferences

class LevelSelectActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_level_select)

        val player = GamePreferences.loadPlayer(this)
        val grid = findViewById<GridLayout>(R.id.gridLevels)
        val totalLevels = 9

        for (i in 1..totalLevels) {
            val btn = Button(this).apply {
                val animals = AnimalCatalog.getAnimalsForLevel(i).joinToString(" ") { it.emoji }
                text = if (i <= player.highestLevel) "المستوى $i\n$animals" else "🔒"
                isEnabled = i <= player.highestLevel
                textSize = 14f
                setPadding(8, 8, 8, 8)

                setOnClickListener {
                    val intent = Intent(this@LevelSelectActivity, GameActivity::class.java)
                    intent.putExtra("level", i)
                    startActivity(intent)
                }
            }

            val params = GridLayout.LayoutParams().apply {
                width = 0
                height = GridLayout.LayoutParams.WRAP_CONTENT
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                setMargins(8, 8, 8, 8)
            }
            btn.layoutParams = params
            grid.addView(btn)
        }
    }
}
