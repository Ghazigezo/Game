package com.hunterGame.activities

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.hunterGame.R
import com.hunterGame.game.GameView
import com.hunterGame.utils.GamePreferences

class GameActivity : AppCompatActivity() {

    private lateinit var gameView: GameView
    private var level = 1
    private var totalScore = 0
    private var totalCoins = 0
    private var gameOverShown = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_game)

        level = intent.getIntExtra("level", 1)
        val player = GamePreferences.loadPlayer(this)

        gameView = findViewById(R.id.gameView)
        gameView.level = level
        gameView.equippedGunId = player.equippedGunId

        gameView.onAnimalKilled = { animal, score, coins ->
            totalScore += score
            totalCoins += coins
            runOnUiThread {
                val tv = findViewById<TextView>(R.id.tvKillFeed)
                tv.text = "+${score} pts  ${animal.emoji} مقتول!"
                tv.visibility = View.VISIBLE
                Handler(Looper.getMainLooper()).postDelayed({ tv.visibility = View.GONE }, 1200)
            }
        }

        gameView.onGameOver = { score, coins ->
            runOnUiThread { showGameOver(score, coins) }
        }
    }

    private fun showGameOver(score: Int, coins: Int) {
        if (gameOverShown) return
        gameOverShown = true

        // Save progress
        val player = GamePreferences.loadPlayer(this)
        player.coins += coins
        player.totalScore += score
        if (level >= player.highestLevel && score > 0) {
            player.highestLevel = minOf(level + 1, 9)
        }
        GamePreferences.savePlayer(this, player)

        val won = score > 0
        val title = if (won) "🎉 أحسنت يا بطل!" else "💀 حاول مجدداً"

        AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage("النقاط: $score\nعملات ربحتها: 💰 $coins")
            .setCancelable(false)
            .setPositiveButton("الرئيسية") { _, _ ->
                startActivity(Intent(this, MainActivity::class.java))
                finish()
            }
            .setNegativeButton("إعادة") { _, _ ->
                val intent = Intent(this, GameActivity::class.java)
                intent.putExtra("level", level)
                startActivity(intent)
                finish()
            }
            .show()
    }

    override fun onPause() {
        super.onPause()
        // GameThread will pause naturally when surface is destroyed
    }
}
