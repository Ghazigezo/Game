package com.hunterGame.game

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import com.hunterGame.models.Animal
import com.hunterGame.models.Gun
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

// Live animal instance on the field
data class AnimalEntity(
    val animal: Animal,
    var x: Float,
    var y: Float,
    var currentHealth: Int,
    val id: Int = Random.nextInt()
) {
    val maxHealth get() = animal.health
    val healthRatio get() = currentHealth.toFloat() / maxHealth
    var isAlive = true
    var direction = if (Random.nextBoolean()) 1f else -1f  // left or right
    var flashTimer = 0f  // red flash on hit
}

// Bullet flying across screen
data class BulletEntity(
    var x: Float,
    var y: Float,
    val damage: Int,
    val speed: Float = 900f
)

class GameEngine(
    private var screenWidth: Float,
    private var screenHeight: Float,
    private val level: Int,
    private val gun: Gun,
    private val animalPool: List<Animal>,
    private val onAnimalKilled: (Animal, Int, Int) -> Unit,  // animal, score, coins
    private val onGameOver: (Int, Int) -> Unit               // score, coins
) {

    // ── State ────────────────────────────────────────────────────────────────
    private val animals = mutableListOf<AnimalEntity>()
    private val bullets = mutableListOf<BulletEntity>()

    var score = 0
        private set
    var coinsEarned = 0
        private set
    var isRunning = true
        private set

    // Level config
    private val animalsToKill = 5 + (level * 3)        // e.g. level 1 = 8, level 5 = 25
    private val spawnInterval = max(0.8f, 2.5f - level * 0.15f)
    private val timeLimit = 60f + level * 10f

    private var animalsKilled = 0
    private var spawnTimer = 0f
    private var timeRemaining = timeLimit
    private var shotCooldown = 0f
    private val shotCooldownMax = 1f / gun.fireRate

    // ── Paints ───────────────────────────────────────────────────────────────
    private val bgPaint = Paint().apply { color = Color.parseColor("#1A3A1A") }

    private val groundPaint = Paint().apply {
        color = Color.parseColor("#5C8A3C")
    }
    private val skyPaint = Paint().apply {
        color = Color.parseColor("#87CEEB")
    }

    private val bulletPaint = Paint().apply {
        color = Color.YELLOW
        style = Paint.Style.FILL
    }

    private val hpBgPaint = Paint().apply {
        color = Color.parseColor("#AA000000")
        style = Paint.Style.FILL
    }
    private val hpFillPaint = Paint().apply {
        color = Color.parseColor("#FF4444")
        style = Paint.Style.FILL
    }
    private val hpGoodPaint = Paint().apply {
        color = Color.parseColor("#44FF44")
        style = Paint.Style.FILL
    }

    private val uiPaint = Paint().apply {
        color = Color.WHITE
        textSize = 52f
        typeface = Typeface.DEFAULT_BOLD
        isAntiAlias = true
    }
    private val smallUiPaint = Paint().apply {
        color = Color.parseColor("#FFD700")
        textSize = 40f
        typeface = Typeface.DEFAULT_BOLD
        isAntiAlias = true
    }

    private val emojiPaint = Paint().apply {
        textSize = 100f
        isAntiAlias = true
        typeface = Typeface.DEFAULT_BOLD
    }

    private val flashPaint = Paint().apply {
        color = Color.parseColor("#88FF0000")
        style = Paint.Style.FILL
    }

    private val groundY = screenHeight * 0.72f

    // ── Public API ───────────────────────────────────────────────────────────

    fun update(deltaTime: Float) {
        if (!isRunning) return

        timeRemaining -= deltaTime
        spawnTimer += deltaTime
        if (shotCooldown > 0) shotCooldown -= deltaTime

        // Spawn
        if (spawnTimer >= spawnInterval && animals.count { it.isAlive } < 5) {
            spawnAnimal()
            spawnTimer = 0f
        }

        // Move animals
        animals.filter { it.isAlive }.forEach { entity ->
            entity.x += entity.direction * entity.animal.speed * deltaTime
            entity.flashTimer = max(0f, entity.flashTimer - deltaTime)
            // Bounce at edges
            val hw = emojiSize(entity) / 2f
            if (entity.x - hw < 0) {
                entity.x = hw
                entity.direction = 1f
            } else if (entity.x + hw > screenWidth) {
                entity.x = screenWidth - hw
                entity.direction = -1f
            }
        }

        // Move bullets
        bullets.forEach { it.x += it.speed * deltaTime }
        bullets.removeAll { it.x > screenWidth + 50 }

        // Collision
        val deadBullets = mutableListOf<BulletEntity>()
        bullets.forEach { bullet ->
            animals.filter { it.isAlive }.forEach { entity ->
                val hw = emojiSize(entity) / 2f
                val hh = emojiSize(entity) / 2f
                if (bullet.x in (entity.x - hw)..(entity.x + hw) &&
                    bullet.y in (entity.y - hh)..(entity.y + hh)
                ) {
                    entity.currentHealth -= bullet.damage
                    entity.flashTimer = 0.15f
                    deadBullets.add(bullet)
                    if (entity.currentHealth <= 0) {
                        entity.isAlive = false
                        animalsKilled++
                        score += entity.animal.scoreValue
                        coinsEarned += entity.animal.coinsValue
                        onAnimalKilled(entity.animal, entity.animal.scoreValue, entity.animal.coinsValue)
                    }
                }
            }
        }
        bullets.removeAll(deadBullets)

        // Win / Lose
        if (animalsKilled >= animalsToKill) {
            isRunning = false
            onGameOver(score, coinsEarned)
        } else if (timeRemaining <= 0) {
            isRunning = false
            onGameOver(score, coinsEarned)
        }

        // Cleanup dead animals after a moment
        animals.removeAll { !it.isAlive && it.flashTimer <= 0f }
    }

    fun shoot(targetX: Float, targetY: Float) {
        if (shotCooldown > 0 || !isRunning) return
        shotCooldown = shotCooldownMax
        // Fire from left side of screen (player position)
        val playerX = 120f
        val playerY = groundY - 60f
        // Calculate direction toward tap
        val dx = targetX - playerX
        val dy = targetY - playerY
        val dist = Math.sqrt((dx * dx + dy * dy).toDouble()).toFloat()
        if (dist == 0f) return
        // Simplified: bullets always go right (landscape hunting game)
        bullets.add(BulletEntity(x = playerX + 60f, y = playerY, damage = gun.damage))
    }

    fun draw(canvas: Canvas) {
        // Sky
        canvas.drawRect(0f, 0f, screenWidth, groundY, skyPaint)
        // Ground
        canvas.drawRect(0f, groundY, screenWidth, screenHeight, groundPaint)

        // Animals
        animals.filter { it.isAlive }.forEach { entity ->
            val size = emojiSize(entity)
            val ey = entity.y - size / 2f

            // Flash overlay
            if (entity.flashTimer > 0f) {
                canvas.drawCircle(entity.x, entity.y, size / 2f, flashPaint)
            }

            // Emoji
            emojiPaint.textSize = size
            canvas.drawText(entity.animal.emoji, entity.x - size / 2f, ey + size * 0.8f, emojiPaint)

            // Health bar
            val barW = size * 1.2f
            val barH = 14f
            val barX = entity.x - barW / 2f
            val barY = ey - 20f
            canvas.drawRoundRect(RectF(barX, barY, barX + barW, barY + barH), 6f, 6f, hpBgPaint)
            val fillPaint = if (entity.healthRatio > 0.5f) hpGoodPaint else hpFillPaint
            canvas.drawRoundRect(
                RectF(barX, barY, barX + barW * entity.healthRatio, barY + barH),
                6f, 6f, fillPaint
            )
        }

        // Bullets
        bullets.forEach { b ->
            canvas.drawCircle(b.x, b.y, 10f, bulletPaint)
        }

        // Player character (Arab hunter emoji)
        emojiPaint.textSize = 110f
        canvas.drawText("🧔🏽", 30f, groundY - 10f, emojiPaint)
        // Gun emoji
        emojiPaint.textSize = 70f
        canvas.drawText(gun.emoji, 120f, groundY - 30f, emojiPaint)

        // HUD
        canvas.drawText("🏆 $score", 20f, 55f, uiPaint)
        canvas.drawText("💰 $coinsEarned", 20f, 105f, smallUiPaint)
        canvas.drawText("🎯 $animalsKilled / $animalsToKill", screenWidth / 2f - 120f, 55f, uiPaint)

        val timeColor = if (timeRemaining < 10f) Color.RED else Color.WHITE
        uiPaint.color = timeColor
        canvas.drawText("⏱ ${timeRemaining.toInt()}s", screenWidth - 250f, 55f, uiPaint)
        uiPaint.color = Color.WHITE

        // Level badge
        smallUiPaint.textSize = 36f
        canvas.drawText("المستوى $level", screenWidth - 220f, 100f, smallUiPaint)
    }

    // ── Helpers ──────────────────────────────────────────────────────────────

    private fun spawnAnimal() {
        val animal = animalPool.random()
        val size = emojiSize(animal)
        val x = if (Random.nextBoolean()) screenWidth - size else size + 50f
        val direction = if (x > screenWidth / 2) -1f else 1f
        animals.add(
            AnimalEntity(
                animal = animal,
                x = x,
                y = groundY - size / 3f,
                currentHealth = animal.health
            ).apply { this.direction = direction }
        )
    }

    private fun emojiSize(entity: AnimalEntity) = 90f * entity.animal.size
    private fun emojiSize(animal: Animal) = 90f * animal.size
}
