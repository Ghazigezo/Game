package com.hunterGame.game

import android.content.Context
import android.graphics.Canvas
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import com.hunterGame.models.Animal
import com.hunterGame.models.AnimalCatalog
import com.hunterGame.models.Gun
import com.hunterGame.models.GunCatalog

class GameView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : SurfaceView(context, attrs), SurfaceHolder.Callback {

    private var gameThread: GameThread? = null
    private var engine: GameEngine? = null

    var level: Int = 1
    var equippedGunId: Int = 1
    var onAnimalKilled: ((Animal, Int, Int) -> Unit)? = null
    var onGameOver: ((Int, Int) -> Unit)? = null

    init {
        holder.addCallback(this)
        isFocusable = true
    }

    override fun surfaceCreated(holder: SurfaceHolder) {
        val gun = GunCatalog.guns.find { it.id == equippedGunId } ?: GunCatalog.guns.first()
        val animals = AnimalCatalog.getAnimalsForLevel(level)

        engine = GameEngine(
            screenWidth = width.toFloat(),
            screenHeight = height.toFloat(),
            level = level,
            gun = gun,
            animalPool = animals,
            onAnimalKilled = { animal, score, coins ->
                onAnimalKilled?.invoke(animal, score, coins)
            },
            onGameOver = { score, coins ->
                onGameOver?.invoke(score, coins)
            }
        )

        gameThread = GameThread(holder, engine!!)
        gameThread?.isRunning = true
        gameThread?.start()
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {}

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        gameThread?.isRunning = false
        gameThread?.join()
        gameThread = null
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action == MotionEvent.ACTION_DOWN || event.action == MotionEvent.ACTION_MOVE) {
            engine?.shoot(event.x, event.y)
        }
        return true
    }
}

class GameThread(
    private val holder: SurfaceHolder,
    private val engine: GameEngine
) : Thread() {

    var isRunning = false
    private var lastTime = System.nanoTime()

    override fun run() {
        while (isRunning && engine.isRunning) {
            val now = System.nanoTime()
            val deltaTime = ((now - lastTime) / 1_000_000_000f).coerceIn(0f, 0.05f)
            lastTime = now

            engine.update(deltaTime)

            val canvas: Canvas? = holder.lockCanvas()
            if (canvas != null) {
                try {
                    engine.draw(canvas)
                } finally {
                    holder.unlockCanvasAndPost(canvas)
                }
            }

            // ~60 FPS
            val sleepTime = 16 - (System.nanoTime() - now) / 1_000_000
            if (sleepTime > 0) sleep(sleepTime)
        }
    }
}
