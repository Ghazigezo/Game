package com.hunterGame.activities

import android.graphics.Color
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.hunterGame.R
import com.hunterGame.models.GunCatalog
import com.hunterGame.utils.GamePreferences

class ShopActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_shop)
        renderShop()
    }

    private fun renderShop() {
        val player = GamePreferences.loadPlayer(this)
        val container = findViewById<LinearLayout>(R.id.shopContainer)
        val tvCoins = findViewById<TextView>(R.id.tvShopCoins)
        tvCoins.text = "💰 ${player.coins} عملة"
        container.removeAllViews()

        GunCatalog.guns.forEach { gun ->
            val owned = player.ownedGunIds.contains(gun.id)
            val equipped = player.equippedGunId == gun.id

            val card = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(24, 24, 24, 24)
                setBackgroundColor(
                    when {
                        equipped -> Color.parseColor("#2E7D32")
                        owned -> Color.parseColor("#1B5E20")
                        else -> Color.parseColor("#212121")
                    }
                )
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { setMargins(0, 0, 0, 16) }
            }

            val info = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }

            val tvName = TextView(this).apply {
                text = "${gun.emoji} ${gun.nameAr}"
                textSize = 20f
                setTextColor(Color.WHITE)
            }
            val tvStats = TextView(this).apply {
                text = "ضرر: ${gun.damage}  |  معدل: ${gun.fireRate}/ث"
                textSize = 14f
                setTextColor(Color.parseColor("#BDBDBD"))
            }

            info.addView(tvName)
            info.addView(tvStats)

            val btn = Button(this).apply {
                text = when {
                    equipped -> "✅ مجهز"
                    owned -> "تجهيز"
                    else -> "شراء\n${gun.price} 💰"
                }
                isEnabled = !equipped
                setOnClickListener {
                    if (owned) {
                        player.equippedGunId = gun.id
                        GamePreferences.savePlayer(this@ShopActivity, player)
                        renderShop()
                    } else if (player.coins >= gun.price) {
                        player.coins -= gun.price
                        player.ownedGunIds.add(gun.id)
                        player.equippedGunId = gun.id
                        GamePreferences.savePlayer(this@ShopActivity, player)
                        Toast.makeText(this@ShopActivity, "تم شراء ${gun.nameAr}! 🎉", Toast.LENGTH_SHORT).show()
                        renderShop()
                    } else {
                        Toast.makeText(this@ShopActivity, "عملاتك غير كافية 😔", Toast.LENGTH_SHORT).show()
                    }
                }
            }

            card.addView(info)
            card.addView(btn)
            container.addView(card)
        }
    }
}
