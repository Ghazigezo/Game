package com.hunterGame.models

data class Animal(
    val id: Int,
    val nameAr: String,
    val nameEn: String,
    val health: Int,
    val speed: Float,       // pixels per second
    val scoreValue: Int,
    val coinsValue: Int,
    val emoji: String,
    val size: Float = 1.0f  // relative size multiplier
)

object AnimalCatalog {

    // Animals unlocked per level
    fun getAnimalsForLevel(level: Int): List<Animal> {
        return when (level) {
            1 -> listOf(rabbit)
            2 -> listOf(rabbit, fox)
            3 -> listOf(rabbit, fox, deer)
            4 -> listOf(fox, deer, wolf)
            5 -> listOf(deer, wolf, boar)
            6 -> listOf(wolf, boar, bear)
            7 -> listOf(boar, bear, lion)
            8 -> listOf(bear, lion, elephant)
            else -> listOf(lion, elephant, crocodile)
        }
    }

    private val rabbit = Animal(1, "أرنب", "Rabbit",
        health = 30, speed = 200f, scoreValue = 10, coinsValue = 5, emoji = "🐰")
    private val fox = Animal(2, "ثعلب", "Fox",
        health = 60, speed = 260f, scoreValue = 25, coinsValue = 15, emoji = "🦊")
    private val deer = Animal(3, "غزال", "Deer",
        health = 80, speed = 320f, scoreValue = 40, coinsValue = 25, emoji = "🦌")
    private val wolf = Animal(4, "ذئب", "Wolf",
        health = 120, speed = 350f, scoreValue = 70, coinsValue = 40, emoji = "🐺")
    private val boar = Animal(5, "خنزير بري", "Boar",
        health = 150, speed = 280f, scoreValue = 90, coinsValue = 55, emoji = "🐗", size = 1.2f)
    private val bear = Animal(6, "دب", "Bear",
        health = 220, speed = 240f, scoreValue = 130, coinsValue = 80, emoji = "🐻", size = 1.4f)
    private val lion = Animal(7, "أسد", "Lion",
        health = 300, speed = 370f, scoreValue = 200, coinsValue = 120, emoji = "🦁", size = 1.5f)
    private val elephant = Animal(8, "فيل", "Elephant",
        health = 500, speed = 200f, scoreValue = 350, coinsValue = 200, emoji = "🐘", size = 2.0f)
    private val crocodile = Animal(9, "تمساح", "Crocodile",
        health = 400, speed = 300f, scoreValue = 280, coinsValue = 160, emoji = "🐊", size = 1.8f)
}
