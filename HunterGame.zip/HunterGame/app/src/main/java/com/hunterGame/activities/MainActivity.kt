package com.hunterGame.activities

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.hunterGame.R
import com.hunterGame.utils.GamePreferences

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    override fun onResume() {
        super.onResume()
        val player = GamePreferences.loadPlayer(this)

        findViewById<TextView>(R.id.tvCoins).text = "💰 ${player.coins}"
        findViewById<TextView>(R.id.tvHighScore).text = "🏆 ${player.totalScore}"
        findViewById<TextView>(R.id.tvLevel).text = "المستوى ${player.highestLevel}"

        findViewById<Button>(R.id.btnPlay).setOnClickListener {
            startActivity(Intent(this, LevelSelectActivity::class.java))
        }

        findViewById<Button>(R.id.btnShop).setOnClickListener {
            startActivity(Intent(this, ShopActivity::class.java))
        }
    }
}
