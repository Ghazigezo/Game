package com.hunterGame.utils

import android.content.Context
import com.google.gson.Gson
import com.hunterGame.models.PlayerState

object GamePreferences {

    private const val PREF_NAME = "hunter_game_prefs"
    private const val KEY_PLAYER = "player_state"
    private val gson = Gson()

    fun savePlayer(context: Context, state: PlayerState) {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString(KEY_PLAYER, gson.toJson(state)).apply()
    }

    fun loadPlayer(context: Context): PlayerState {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val json = prefs.getString(KEY_PLAYER, null) ?: return PlayerState()
        return try {
            gson.fromJson(json, PlayerState::class.java)
        } catch (e: Exception) {
            PlayerState()
        }
    }

    fun resetPlayer(context: Context) {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        prefs.edit().clear().apply()
    }
}
