# 🧔🏽 الصياد العربي — Arab Hunter Game

A native Android hunting game built in **Kotlin**.

## 📁 Project Structure

```
HunterGame/
├── app/
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/hunterGame/
│       │   ├── activities/
│       │   │   ├── SplashActivity.kt       ← Launch screen
│       │   │   ├── MainActivity.kt         ← Main menu
│       │   │   ├── LevelSelectActivity.kt  ← Level picker
│       │   │   ├── GameActivity.kt         ← Game host
│       │   │   └── ShopActivity.kt         ← Gun shop
│       │   ├── game/
│       │   │   ├── GameEngine.kt           ← Core game logic
│       │   │   └── GameView.kt             ← SurfaceView + game loop
│       │   ├── models/
│       │   │   ├── Animal.kt               ← Animal catalog (9 animals)
│       │   │   ├── Gun.kt                  ← Gun catalog (6 guns)
│       │   │   └── PlayerState.kt          ← Player data model
│       │   └── utils/
│       │       └── GamePreferences.kt      ← SharedPreferences save/load
│       └── res/
│           ├── layout/                     ← XML layouts
│           └── values/                     ← Strings, themes
├── build.gradle
├── settings.gradle
└── gradle.properties
```

## 🎮 Gameplay

- **Tap the screen** to shoot at animals running across the field
- **Kill enough animals** before the timer runs out to win the level
- Each level introduces **new harder animals** 🐰→🦊→🦌→🐺→🐗→🐻→🦁→🐘→🐊
- Earn **coins** for every kill → spend them in the gun shop

## 🔫 Guns (6 total)

| Gun | Damage | Fire Rate | Price |
|-----|--------|-----------|-------|
| مسدس الصحراء (Pistol) | 20 | 1/s | Free |
| بندقية الصياد (Rifle) | 45 | 1/s | 500 💰 |
| قاطعة الريح | 60 | 2/s | 1,200 💰 |
| مدفع الصحراء | 90 | 1/s | 2,500 💰 |
| بندقية الفالكون | 120 | 1/s | 4,000 💰 |
| مدفع الرعد | 75 | 3/s | 6,000 💰 |

## 🚀 Setup in Android Studio

1. Open **Android Studio** → File → Open → select `HunterGame/`
2. Wait for Gradle sync
3. Add a launcher icon: right-click `res` → New → Image Asset → name it `ic_launcher`
4. Run on emulator or device (API 24+, landscape orientation)

## 🛠 Add Sounds (Optional)

Place `.mp3` or `.ogg` files in `res/raw/`:
- `shot.mp3` — gunshot
- `animal_die.mp3` — animal killed
- `bgm.mp3` — background music

Then use `MediaPlayer` or `SoundPool` in `GameEngine.kt`.

## 📦 Dependencies

- Kotlin 1.9
- AndroidX AppCompat, ConstraintLayout
- Material Components
- Gson (for save data serialization)
